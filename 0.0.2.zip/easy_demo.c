#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "i2c_s1_key.h"

typedef struct func_param
{
	int				i2c_fd;
	unsigned char	i2c_addr;
}FUNC_PARAM;
/*
 * S1 �������Ժ���
 */
void s1_key_func(FUNC_PARAM param)
{
	//char				devName[16];
	int					ret;
	unsigned char		key;
	//��ʼ��
	I2c_s1_key_init(param.i2c_fd, param.i2c_addr);
	while(1)
	{
		ret = I2c_s1_key_get(param.i2c_fd, param.i2c_addr, &key);
		if(!ret)
		{
			printf("key %d pressed\n", key);
			printf("ret==%s\n",ret);
			printf("111111111111111111111111111111111111111111111111111111111111111111111111111111111\n");

		}
		usleep(500000);
	}
 }
/*
 * main
 */
int main(int argc, char **argv)
{
	int					isOnline;
	int					i2c_fd;
	unsigned char		i2c_addr;
	char				devname[16];
	int					i;
	FUNC_PARAM			param;
	isOnline = 0;
	//S1������״̬���
	for(i=I2C_DEV_NO_START; i<(I2C_DEV_NO_START+I2C_DEV_NUM); i++)
	{
		sprintf(devname, "%s%d", I2C_DEV_NAME_COMMON, i);
		//open
		i2c_fd = I2c_open(devname);
		if(i2c_fd > 0)
		{
			memset(&param, 0, sizeof(param));
			//S1 key detect
			if(I2c_s1_key_detect(i2c_fd, &i2c_addr) >= 0)
			{
				isOnline = 1;
				param.i2c_fd = i2c_fd;
				param.i2c_addr = i2c_addr;
				//S1��������
				s1_key_func(param);
			}
			//close
			I2c_close(i2c_fd);
			//�ҵ�һ��S1��
			if(isOnline)
				break;
		}
	}

	if(!isOnline)
	{
		printf("No S1 test board found.\n");
		return -1;
	}

    return 0;
}
